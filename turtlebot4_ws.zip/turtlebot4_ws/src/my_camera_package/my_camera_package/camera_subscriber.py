import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np

class CameraSubscriber(Node):
    def __init__(self):
        super().__init__('camera_subscriber')
        self.subscription = self.create_subscription(
            Image,
            '/oakd/rgb/preview/image_raw',  # Ajusta esto al nombre correcto de tu tópico
            self.listener_callback,
            10
        )
        self.subscription  
        self.bridge = CvBridge()

    def listener_callback(self, msg):
        # Convertir el mensaje de ROS Image a una imagen de OpenCV
        cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")

        # Convertir la imagen a espacio de color HSV
        hsv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)

        # Definir los rangos de colores (Rojo, Verde y Azul)
        # Rojo
        lower_red = np.array([0, 120, 70])
        upper_red = np.array([10, 255, 255])
        mask_red = cv2.inRange(hsv_image, lower_red, upper_red)
        result_red = cv2.bitwise_and(cv_image, cv_image, mask=mask_red)

        # Verde
        lower_green = np.array([35, 100, 100])
        upper_green = np.array([85, 255, 255])
        mask_green = cv2.inRange(hsv_image, lower_green, upper_green)
        result_green = cv2.bitwise_and(cv_image, cv_image, mask=mask_green)

        # Azul
        lower_blue = np.array([100, 100, 100])
        upper_blue = np.array([140, 255, 255])
        mask_blue = cv2.inRange(hsv_image, lower_blue, upper_blue)
        result_blue = cv2.bitwise_and(cv_image, cv_image, mask=mask_blue)

        # Mostrar las imágenes de resultados
        cv2.imshow("Original", cv_image)
        cv2.imshow("Filtered Red Color", result_red)
        cv2.imshow("Filtered Green Color", result_green)
        cv2.imshow("Filtered Blue Color", result_blue)

        # Imprimir en consola los colores detectados
        if np.any(mask_red):
            print("Red detected!")
        if np.any(mask_green):
            print("Green detected!")
        if np.any(mask_blue):
            print("Blue detected!")

        # Esperar por un evento de tecla para cerrar las ventanas
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    camera_subscriber = CameraSubscriber()
    rclpy.spin(camera_subscriber)
    camera_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
