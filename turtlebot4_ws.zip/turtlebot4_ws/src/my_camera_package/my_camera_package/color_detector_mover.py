import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import cv2
import numpy as np

class MoveUntilBlue(Node):
    def __init__(self):
        super().__init__('move_until_blue')
        # Publicar en el tópico cmd_vel para controlar el robot
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        # Suscribirse a la cámara
        self.subscription = self.create_subscription(
            Image,
            '/oakd/rgb/preview/image_raw',  # Cambia este nombre si es diferente en tu sistema
            self.listener_callback,
            10
        )
        self.bridge = CvBridge()
        self.twist = Twist()

        # Configurar velocidades de movimiento
        self.forward_speed = 0.1  # Velocidad lineal hacia adelante
        self.rotation_speed = 0.3  # Velocidad angular para girar

        # Rango del color azul en HSV
        self.lower_blue = np.array([100, 150, 50])
        self.upper_blue = np.array([140, 255, 255])

        # Coordenadas del área objetivo
        self.start_point = (77, 119)
        self.end_point = (242, 148)

        # Estados del robot
        self.searching = True  # Estado inicial: buscando color
        self.target_reached = False  # Estado para indicar si se alcanzó el objetivo

    def listener_callback(self, msg):
        if self.target_reached:
            return  # Si ya alcanzamos el objetivo, no hacemos nada

        # Convertir el mensaje de ROS Image a una imagen de OpenCV
        cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")

        # Convertir la imagen a espacio de color HSV
        hsv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)

        # Crear una máscara que detecta solo el color azul
        mask_blue = cv2.inRange(hsv_image, self.lower_blue, self.upper_blue)

        # Verificar si el color azul está presente en cualquier parte de la imagen
        blue_detected = np.sum(mask_blue) > 0

        # Recortar la región de interés (ROI) de la máscara
        roi = mask_blue[self.start_point[1]:self.end_point[1], self.start_point[0]:self.end_point[0]]

        # Calcular la suma de los valores dentro del ROI (indica la presencia de azul en el área objetivo)
        blue_in_roi = np.sum(roi) > 0

        # Dibujar el rectángulo amarillo en la imagen original para visualización
        cv2.rectangle(cv_image, self.start_point, self.end_point, (0, 255, 255), 2)

        # Lógica para mover el robot
        if self.searching:
            if blue_detected:
                self.get_logger().info("¡Color azul encontrado! Cambiando a modo de ajuste.")
                self.searching = False  # Cambiar al modo de ajuste
            else:
                self.get_logger().info("Buscando el color azul...")
                self.twist.linear.x = 0.0  # Detener avance
                self.twist.angular.z = self.rotation_speed  # Girar para buscar
        else:
            if blue_in_roi:
                self.get_logger().info("¡Azul detectado en el área objetivo! Deteniendo robot.")
                print("Objetivo alcanzado: el color azul está dentro del área objetivo.")
                self.twist.linear.x = 0.0  # Detener el avance
                self.twist.angular.z = 0.0  # Detener el giro
                self.target_reached = True  # Marcar como objetivo alcanzado
            else:
                self.get_logger().info("Ajustando posición hacia el color azul...")
                self.twist.linear.x = self.forward_speed  # Avanzar hacia adelante
                self.twist.angular.z = 0.0  # Ajustar dirección sin girar

        # Publicar el mensaje de movimiento
        self.publisher_.publish(self.twist)

        # Mostrar la imagen original con el rectángulo y la máscara
        cv2.imshow("Original with Rectangles", cv_image)
        cv2.imshow("Blue Mask", mask_blue)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    move_until_blue = MoveUntilBlue()
    rclpy.spin(move_until_blue)
    move_until_blue.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
