from setuptools import setup

package_name = 'my_camera_package'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Tu Nombre',
    maintainer_email='tu_email@example.com',
    description='Nodo para trabajar con la cámara del TurtleBot 4',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'camera_subscriber = my_camera_package.camera_subscriber:main',
            'color_detector_mover = my_camera_package.color_detector_mover:main'
        ],
    },
)
