^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot4_ignition_gui_plugins
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.2 (2024-04-15)
------------------

1.0.1 (2023-11-08)
------------------

1.0.0 (2023-05-16)
------------------
* Updated GUI to have namespace input
* Contributors: Hilary Luo, Roni Kreinin, roni-kreinin

0.1.1 (2022-05-09)
------------------

0.1.0 (2022-05-04)
------------------
* First Galactic release
* Contributors: Roni Kreinin
